create table Usersexam ( userId number primary key,
 userName varchar(20),userEmail varchar(20),
 password varchar2(20),phoneNo number, city varchar(20),State varchar(20)
 ,qualification varchar(20));